// const property = {}
// property.type: "casa", 
// property.rentSell= "aluga";
// property.roons= 2;
// property.bathroons= 2;
// property.parking= "sim";
// property.neighborhood = "petrop"

// console.log(property)

const property = {
  type: "",
  rentSell: "",
  rooms: 0,
  bathrooms: 0,
  parking: "",
  neighborhood: ""
}

property.type = "casa"
property.rentSell = "aluga"
property.rooms = 2
property.bathrooms = 2
property.parking = "sim"
property.neighborhood = "petrop"

console.log(property)

